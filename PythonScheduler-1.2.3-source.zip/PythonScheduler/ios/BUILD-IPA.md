# Build unsigned IPA

This source tree is prepared to produce an unsigned IPA on macOS with Xcode installed.
The current execution environment is Linux and does not include Apple's iOS SDK or Xcode,
so it cannot compile SwiftUI into a real iOS app binary here.

## Local build (macOS)

```bash
cd PythonScheduler/ios
bash scripts/build-unsigned-ipa.sh
```

Output: `ios/build/PythonScheduler-unsigned.ipa`.

The IPA is unsigned (`CODE_SIGNING_ALLOWED=NO`). Sign it with your own certificate/profile
before installing. The bundle identifier is `com.openai.PythonScheduler` and deployment
minimum is iOS 17.0.

## GitHub Actions

Push this project to a GitHub repository, open Actions, select **Build unsigned iOS IPA**,
and choose **Run workflow**. Download the `PythonScheduler-unsigned-IPA` artifact from the
completed workflow run. GitHub-hosted macOS runners provide Xcode/iOS SDK.

## Important runtime note

The IPA is only the management UI. It talks to the companion rootless jailbreak service at
`http://127.0.0.1:18765`; install and start the matching DEB on the jailbroken device as well.
