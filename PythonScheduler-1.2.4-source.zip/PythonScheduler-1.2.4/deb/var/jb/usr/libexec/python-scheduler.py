#!/var/jb/usr/bin/python3
"""PythonScheduler local API and launchd scheduler for rootless iOS jailbreaks."""
import os, json, time, uuid, base64, threading, subprocess, datetime, re, shutil, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

ROOT = os.environ.get('PYTHONSCHEDULER_ROOT', '/var/mobile/Library/PythonScheduler')
SCRIPTS = os.path.join(ROOT, 'Scripts')
ENVS = os.path.join(ROOT, 'Environments')
LOG = os.path.join(ROOT, 'scheduler.log')
DB = os.path.join(ROOT, 'tasks.json')
PYTHON = os.environ.get('PYTHONSCHEDULER_PYTHON', sys.executable)
PORT = int(os.environ.get('PYTHONSCHEDULER_PORT', '18765'))
MAX_BODY = 3 * 1024 * 1024
ID_RE = re.compile(r'^[a-f0-9]{32}$')
os.makedirs(SCRIPTS, exist_ok=True)
os.makedirs(ENVS, exist_ok=True)
lock = threading.RLock()
running = set()


def read_tasks():
    try:
        with open(DB, encoding='utf-8') as f:
            value = json.load(f)
        return value if isinstance(value, list) else []
    except (OSError, ValueError):
        return []


def write_tasks(tasks):
    tmp = DB + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(tasks, f, indent=2, ensure_ascii=False)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, DB)


def log(message):
    stamp = datetime.datetime.now().astimezone().isoformat(timespec='seconds')
    with open(LOG, 'a', encoding='utf-8') as f:
        f.write('[%s] %s\n' % (stamp, str(message)))


def safe_id(value):
    return isinstance(value, str) and bool(ID_RE.fullmatch(value))


def ensure_env(sid):
    if not safe_id(sid):
        raise ValueError('invalid script id')
    envdir = os.path.join(ENVS, sid)
    py = os.path.join(envdir, 'bin', 'python3')
    if not os.path.isfile(py):
        subprocess.run([PYTHON, '-m', 'venv', envdir], check=True, timeout=240,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if not os.path.isfile(py):
        py = os.path.join(envdir, 'bin', 'python')
    if not os.path.isfile(py):
        raise RuntimeError('venv did not create a Python executable; verify Python venv/ensurepip support')
    return py


def run_task(task):
    sid = task.get('script_id', '')
    if not safe_id(sid):
        log('ERROR invalid script id')
        return
    path = os.path.join(SCRIPTS, sid + '.py')
    if not os.path.isfile(path):
        log('ERROR missing script ' + sid)
        return
    with lock:
        if sid in running:
            log('SKIP already running: ' + task.get('name', sid))
            return
        running.add(sid)
    try:
        py = ensure_env(sid)
        timeout = max(1, min(int(task.get('timeout', 3600)), 86400))
        proc = subprocess.run([py, path], capture_output=True, text=True,
                               timeout=timeout, cwd=ROOT)
        log('%s exit=%s\n%s\n%s' % (task.get('name', sid), proc.returncode,
                                    proc.stdout[-8000:], proc.stderr[-8000:]))
    except subprocess.TimeoutExpired:
        log('ERROR timeout: ' + task.get('name', sid))
    except Exception as exc:
        log('ERROR %s: %s' % (task.get('name', sid), exc))
    finally:
        with lock:
            running.discard(sid)


def is_due(task, now, epoch):
    if not task.get('enabled', True):
        return False
    mode = task.get('mode', 'daily')
    last = task.get('last_run', '')
    today = now.strftime('%Y-%m-%d')
    if mode == 'interval':
        interval = max(1, min(int(task.get('minutes', 60)), 525600)) * 60
        anchor = float(task.get('last_epoch') or task.get('created_epoch') or epoch)
        return epoch - anchor >= interval
    if mode == 'once':
        return not last and task.get('date') == today and now.strftime('%H:%M') >= task.get('time', '09:00')
    if mode == 'weekly':
        days = [str(x).lower()[:3] for x in task.get('days', ['mon'])]
        weekday_codes = ('mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun')
        if weekday_codes[now.weekday()] not in days:
            return False
    return now.strftime('%H:%M') >= task.get('time', '09:00') and last != today


def scheduler():
    while True:
        now = datetime.datetime.now().astimezone()
        epoch = time.time()
        try:
            with lock:
                tasks = read_tasks()
                changed = False
                for task in tasks:
                    try:
                        if is_due(task, now, epoch):
                            task['last_run'] = now.strftime('%Y-%m-%d')
                            task['last_epoch'] = epoch
                            changed = True
                            threading.Thread(target=run_task, args=(dict(task),), daemon=True).start()
                    except Exception as exc:
                        log('ERROR schedule %s: %s' % (task.get('name', '?'), exc))
                if changed:
                    write_tasks(tasks)
        except Exception as exc:
            log('ERROR scheduler loop: %s' % exc)
        time.sleep(15)


class SchedulerHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class Handler(BaseHTTPRequestHandler):
    server_version = 'PythonScheduler/1.2.4'

    def log_message(self, *_):
        pass

    def send_json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def body(self):
        length = int(self.headers.get('Content-Length', '0'))
        if length < 0 or length > MAX_BODY:
            raise ValueError('request body too large')
        raw = self.rfile.read(length) if length else b'{}'
        value = json.loads(raw.decode('utf-8'))
        if not isinstance(value, dict):
            raise ValueError('JSON object required')
        return value

    def do_GET(self):
        p = urlparse(self.path).path
        if p == '/health':
            return self.send_json(200, {'ok': True, 'python': PYTHON, 'version': '1.2.4', 'running': len(running)})
        if p == '/tasks':
            return self.send_json(200, read_tasks())
        if p == '/scripts':
            items = []
            for filename in os.listdir(SCRIPTS):
                if filename.endswith('.py'):
                    sid = filename[:-3]
                    try:
                        with open(os.path.join(SCRIPTS, sid + '.name'), encoding='utf-8') as f:
                            name = f.read().strip()
                    except OSError:
                        name = filename
                    items.append({'id': sid, 'name': name or filename})
            return self.send_json(200, sorted(items, key=lambda x: x['name'].lower()))
        if p == '/logs':
            try:
                with open(LOG, encoding='utf-8', errors='replace') as f:
                    data = f.read()[-50000:]
            except OSError:
                data = ''
            return self.send_json(200, {'logs': data})
        return self.send_json(404, {'error': 'not found'})

    def do_POST(self):
        try:
            data = self.body()
        except Exception as exc:
            return self.send_json(400, {'error': str(exc)})
        p = urlparse(self.path).path
        try:
            if p == '/scripts':
                name = os.path.basename(str(data.get('name', 'script.py'))).strip()[:128]
                if not name:
                    name = 'script.py'
                if not name.endswith('.py'):
                    name += '.py'
                content = base64.b64decode(data.get('content', ''), validate=True)
                if not content or len(content) > 2 * 1024 * 1024:
                    return self.send_json(413, {'error': 'script must be 1 byte to 2 MiB'})
                sid = uuid.uuid4().hex
                with open(os.path.join(SCRIPTS, sid + '.py'), 'wb') as f:
                    f.write(content)
                with open(os.path.join(SCRIPTS, sid + '.name'), 'w', encoding='utf-8') as f:
                    f.write(name)
                return self.send_json(201, {'id': sid, 'name': name})
            if p == '/tasks':
                sid = data.get('script_id')
                if not safe_id(sid) or not os.path.isfile(os.path.join(SCRIPTS, sid + '.py')):
                    return self.send_json(400, {'error': 'script not found'})
                mode = data.get('mode', 'daily')
                if mode not in ('daily', 'interval', 'weekly', 'once'):
                    return self.send_json(400, {'error': 'unsupported schedule mode'})
                task = {'id': uuid.uuid4().hex, 'name': str(data.get('name', 'Task'))[:100],
                        'script_id': sid, 'mode': mode, 'time': str(data.get('time', '09:00')),
                        'minutes': max(1, min(int(data.get('minutes', 60)), 525600)),
                        'days': data.get('days', ['mon']), 'date': str(data.get('date', '')),
                        'enabled': True, 'last_run': '', 'last_epoch': 0,
                        'created_epoch': time.time(), 'timeout': max(1, min(int(data.get('timeout', 3600)), 86400))}
                if not re.fullmatch(r'\d{2}:\d{2}', task['time']) or int(task['time'][:2]) > 23 or int(task['time'][3:]) > 59:
                    return self.send_json(400, {'error': 'time must be HH:MM'})
                if mode == 'weekly':
                    valid_days = {'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'}
                    if not isinstance(task['days'], list) or not task['days'] or any(str(day).lower()[:3] not in valid_days for day in task['days']):
                        return self.send_json(400, {'error': 'weekly days must contain valid weekday codes'})
                    task['days'] = sorted({str(day).lower()[:3] for day in task['days']})
                if mode == 'once':
                    try:
                        datetime.datetime.strptime(task['date'], '%Y-%m-%d')
                    except (TypeError, ValueError):
                        return self.send_json(400, {'error': 'once date must be YYYY-MM-DD'})
                with lock:
                    tasks = read_tasks(); tasks.append(task); write_tasks(tasks)
                return self.send_json(201, task)
            if p == '/run':
                sid = data.get('script_id', '')
                if not safe_id(sid) or not os.path.isfile(os.path.join(SCRIPTS, sid + '.py')):
                    return self.send_json(400, {'error': 'script not found'})
                threading.Thread(target=run_task, args=({'script_id': sid, 'name': data.get('name', 'Manual run')},), daemon=True).start()
                return self.send_json(202, {'started': True})
            if p == '/pip':
                sid = data.get('script_id')
                package = str(data.get('package', '')).strip()
                if (not safe_id(sid) or not os.path.isfile(os.path.join(SCRIPTS, sid + '.py'))
                        or not package or len(package) > 256
                        or package.startswith('-') or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*(?:\[[A-Za-z0-9_,.-]+\])?(?:(?:===|==|~=|!=|<=|>=|<|>)[A-Za-z0-9.*+!_-]+)?', package)):
                    return self.send_json(400, {'error': 'invalid package or script id'})
                py = ensure_env(sid)
                result = subprocess.run([py, '-m', 'pip', 'install', '--disable-pip-version-check', package],
                                        capture_output=True, text=True, timeout=900)
                return self.send_json(200, {'returncode': result.returncode,
                                            'stdout': result.stdout[-12000:], 'stderr': result.stderr[-12000:]})
            if p == '/requirements':
                sid = data.get('script_id')
                requirements = data.get('requirements', '')
                if (not safe_id(sid) or not os.path.isfile(os.path.join(SCRIPTS, sid + '.py'))
                        or not isinstance(requirements, str) or not requirements.strip()
                        or len(requirements.encode('utf-8')) > 64 * 1024):
                    return self.send_json(400, {'error': 'invalid requirements or script id'})
                reqfile = os.path.join(ENVS, sid + '.requirements.txt')
                with open(reqfile, 'w', encoding='utf-8') as f:
                    f.write(requirements)
                py = ensure_env(sid)
                result = subprocess.run([py, '-m', 'pip', 'install', '--disable-pip-version-check', '-r', reqfile],
                                        capture_output=True, text=True, timeout=1800)
                return self.send_json(200, {'returncode': result.returncode,
                                            'stdout': result.stdout[-12000:], 'stderr': result.stderr[-12000:]})
        except Exception as exc:
            log('API ERROR %s: %s' % (p, exc))
            return self.send_json(500, {'error': str(exc)[:500]})
        return self.send_json(404, {'error': 'not found'})

    def do_PATCH(self):
        parts = urlparse(self.path).path.strip('/').split('/')
        if len(parts) != 2 or parts[0] != 'tasks':
            return self.send_json(404, {'error': 'not found'})
        try:
            data = self.body()
            with lock:
                tasks = read_tasks()
                found = next((t for t in tasks if t.get('id') == parts[1]), None)
                if not found:
                    return self.send_json(404, {'error': 'task not found'})
                if 'enabled' in data:
                    found['enabled'] = bool(data['enabled'])
                write_tasks(tasks)
            return self.send_json(200, found)
        except Exception as exc:
            return self.send_json(400, {'error': str(exc)})

    def do_DELETE(self):
        parts = urlparse(self.path).path.strip('/').split('/')
        if len(parts) != 2:
            return self.send_json(404, {'error': 'not found'})
        if parts[0] == 'tasks':
            with lock:
                tasks = [t for t in read_tasks() if t.get('id') != parts[1]]
                write_tasks(tasks)
            return self.send_json(200, {'ok': True})
        if parts[0] == 'scripts' and safe_id(parts[1]):
            with lock:
                tasks = [t for t in read_tasks() if t.get('script_id') != parts[1]]
                write_tasks(tasks)
            shutil.rmtree(os.path.join(ENVS, parts[1]), ignore_errors=True)
            try:
                os.remove(os.path.join(ENVS, parts[1] + '.requirements.txt'))
            except OSError:
                pass
            for suffix in ('.py', '.name'):
                try:
                    os.remove(os.path.join(SCRIPTS, parts[1] + suffix))
                except OSError:
                    pass
            return self.send_json(200, {'ok': True})
        return self.send_json(404, {'error': 'not found'})


if __name__ == '__main__':
    log('PythonScheduler backend 1.2.4 started; interpreter=' + PYTHON)
    threading.Thread(target=scheduler, daemon=True).start()
    SchedulerHTTPServer(('127.0.0.1', PORT), Handler).serve_forever()
