#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PROJECT="$ROOT/PythonScheduler.xcodeproj"
OUT="$ROOT/build"
rm -rf "$OUT"
mkdir -p "$OUT/Payload"
xcodebuild \
  -project "$PROJECT" \
  -scheme PythonScheduler \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath "$OUT/DerivedData" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY='' \
  build
APP="$OUT/DerivedData/Build/Products/Release-iphoneos/PythonScheduler.app"
if [ ! -d "$APP" ]; then echo "Build did not produce .app" >&2; exit 1; fi
/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$APP/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$APP/Info.plist" >/dev/null
cp -R "$APP" "$OUT/Payload/"
(cd "$OUT" && /usr/bin/zip -qry PythonScheduler-unsigned.ipa Payload)
/usr/bin/unzip -t "$OUT/PythonScheduler-unsigned.ipa"
echo "Created: $OUT/PythonScheduler-unsigned.ipa"
