import SwiftUI

@main
struct PythonSchedulerApp: App {
    var body: some Scene { WindowGroup { ContentView() } }
}

struct TaskItem: Identifiable, Decodable {
    let id: String
    let name: String
    let script_id: String
    let mode: String
    let time: String
    let minutes: Int
    let enabled: Bool
    let days: [String]?
    let date: String?
}
struct ScriptItem: Identifiable, Decodable { let id: String; let name: String }
struct WeekDay: Identifiable { let code: String; let title: String; var id: String { code } }

@MainActor final class Store: ObservableObject {
    @Published var tasks: [TaskItem] = []
    @Published var scripts: [ScriptItem] = []
    @Published var logs = ""
    @Published var status = "正在连接后台服务…"
    let base = URL(string: "http://127.0.0.1:18765")!
    func request(_ path: String, method: String = "GET", body: Data? = nil, timeout: TimeInterval = 30) async throws -> Data {
        var r = URLRequest(url: base.appendingPathComponent(path)); r.httpMethod = method; r.httpBody = body
        r.setValue("application/json", forHTTPHeaderField: "Content-Type")
        r.timeoutInterval = timeout
        let (data, response) = try await URLSession.shared.data(for: r)
        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            let detail = String(data: data, encoding: .utf8) ?? "HTTP \(http.statusCode)"
            throw NSError(domain: "PythonSchedulerAPI", code: http.statusCode,
                          userInfo: [NSLocalizedDescriptionKey: detail])
        }
        return data
    }
    func refresh() async {
        do {
            let health = try await request("health")
            let h = try JSONSerialization.jsonObject(with: health) as? [String:Any]
            guard h?["ok"] as? Bool == true else { throw URLError(.cannotConnectToHost) }
            status = "后台服务已连接 · Python 3"
        } catch { status = "无法连接后台服务，请确认已安装并启动 PythonScheduler.deb" }
        do { scripts = try JSONDecoder().decode([ScriptItem].self, from: try await request("scripts")) } catch {}
        do { let d = try await request("logs"); let o = try JSONSerialization.jsonObject(with:d) as? [String:String]; logs = o?["logs"] ?? "" } catch {}
        do { tasks = try JSONDecoder().decode([TaskItem].self, from: try await request("tasks")) } catch {}
    }
    func addScript(name: String, data: Data) async throws {
        let payload:[String:Any] = ["name":name,"content":data.base64EncodedString()]
        let body = try JSONSerialization.data(withJSONObject:payload)
        _ = try await request("scripts",method:"POST",body:body); await refresh()
    }
    func addTask(name:String, script:String, mode:String, time:String, minutes:Int, days:[String] = [], date:String = "") async throws {
        let p:[String:Any] = ["name":name,"script_id":script,"mode":mode,"time":time,"minutes":minutes,"days":days,"date":date]
        _ = try await request("tasks",method:"POST",body:JSONSerialization.data(withJSONObject:p)); await refresh()
    }
    func setTask(_ task:TaskItem, enabled:Bool) async {
        let body = try? JSONSerialization.data(withJSONObject:["enabled":enabled])
        _ = try? await request("tasks/\(task.id)",method:"PATCH",body:body); await refresh()
    }
    func run(_ script: ScriptItem) async throws {
        let b = try JSONSerialization.data(withJSONObject:["script_id":script.id,"name":script.name])
        _ = try await request("run",method:"POST",body:b); await refresh()
    }
    func installRequirements(_ text:String, script:String) async throws -> String {
        let b = try JSONSerialization.data(withJSONObject:["script_id":script,"requirements":text])
        let d = try await request("requirements",method:"POST",body:b,timeout:1800)
        return String(data:d,encoding:.utf8) ?? "完成"
    }
    func installPackage(_ package:String, script:String) async throws -> String {
        let b = try JSONSerialization.data(withJSONObject:["script_id":script,"package":package])
        let d = try await request("pip",method:"POST",body:b,timeout:900)
        return String(data:d,encoding:.utf8) ?? "完成"
    }
}

struct ContentView: View {
    @StateObject private var store = Store()
    @State private var showImporter = false
    @State private var showRequirementsImporter = false
    @State private var showAddTask = false
    @State private var packageName = ""
    @State private var selectedScript = ""
    @State private var packageResult = ""
    var body: some View {
        TabView {
            NavigationStack { home }.tabItem { Label("任务",systemImage:"clock") }
            NavigationStack { scriptPage }.tabItem { Label("脚本",systemImage:"chevron.left.forwardslash.chevron.right") }
            NavigationStack { libraryPage }.tabItem { Label("pip",systemImage:"shippingbox") }
            NavigationStack { logPage }.tabItem { Label("日志",systemImage:"doc.text") }
        }.preferredColorScheme(.dark).task { await store.refresh() }
    }
    var home: some View {
        List {
            Section { VStack(alignment:.leading,spacing:8) { Text("Python Scheduler 1.2.4").font(.largeTitle.bold()); Text(store.status).font(.footnote).foregroundStyle(.secondary); HStack { Label("\(store.tasks.count) 个定时任务",systemImage:"calendar"); Spacer(); Label("\(store.scripts.count) 个脚本",systemImage:"doc") }.font(.caption) }.padding(.vertical,8) }
            Section("定时任务") {
                ForEach(store.tasks) { t in HStack {
                    VStack(alignment:.leading,spacing:4) { Text(t.name).font(.headline); Text(t.mode == "interval" ? "每 \(t.minutes) 分钟" : (t.mode == "weekly" ? "每周 \(t.days?.joined(separator:",") ?? "") · \(t.time)" : (t.mode == "once" ? "单次 · \(t.date ?? "") · \(t.time)" : "每天 · \(t.time)"))).font(.caption).foregroundStyle(.secondary) }
                    Spacer(); Toggle("启用",isOn:Binding(get:{t.enabled},set:{v in Task { await store.setTask(t,enabled:v) }})).labelsHidden()
                } }
                .onDelete { offsets in Task { for i in offsets { let id=store.tasks[i].id; _ = try? await store.request("tasks/\(id)",method:"DELETE") }; await store.refresh() } }
                Button { showAddTask=true } label: { Label("添加定时任务",systemImage:"plus.circle.fill") }
            }
        }.navigationTitle("控制台").toolbar { Button { Task { await store.refresh() } } label: { Image(systemName:"arrow.clockwise") } }
        .sheet(isPresented:$showAddTask) { AddTaskView(store:store) }
    }
    var scriptPage: some View {
        List {
            Section { Button { showImporter=true } label: { Label("导入 .py 脚本",systemImage:"plus") } }
            Section("我的脚本") {
                ForEach(store.scripts) { s in
                    HStack { VStack(alignment:.leading) { Text(s.name); Text(s.id).font(.caption2).foregroundStyle(.secondary) }; Spacer(); Button("运行") { Task { try? await store.run(s) } }.buttonStyle(.borderedProminent) }
                }.onDelete { offsets in Task { for i in offsets { _ = try? await store.request("scripts/\(store.scripts[i].id)",method:"DELETE") }; await store.refresh() } }
            }
        }.navigationTitle("脚本管理")
        .fileImporter(isPresented:$showImporter,allowedContentTypes:[.pythonScript],allowsMultipleSelection:true) { result in
            guard case .success(let urls)=result else { return }
            Task {
                for url in urls {
                    let access=url.startAccessingSecurityScopedResource()
                    defer { if access { url.stopAccessingSecurityScopedResource() } }
                    if let d=try? Data(contentsOf:url) { try? await store.addScript(name:url.lastPathComponent,data:d) }
                }
            }
        }
    }
    var libraryPage: some View {
        Form {
            Section("安装第三方库") {
                Picker("所属脚本",selection:$selectedScript) { ForEach(store.scripts) { Text($0.name).tag($0.id) } }
                TextField("包名，例如 requests",text:$packageName).textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("使用 pip 安装") { Task { packageResult=(try? await store.installPackage(packageName,script:selectedScript)) ?? "安装失败" } }.disabled(selectedScript.isEmpty || packageName.isEmpty)
                Button("导入 requirements.txt") { showRequirementsImporter=true }.disabled(selectedScript.isEmpty)
                Text(packageResult).font(.caption).textSelection(.enabled)
            }
            Section { Text("每个脚本使用独立虚拟环境，依赖不会互相覆盖。安装 Python 包需要网络连接。") .font(.footnote).foregroundStyle(.secondary) }
        }.navigationTitle("Python 库")
        .fileImporter(isPresented:$showRequirementsImporter,allowedContentTypes:[.plainText],allowsMultipleSelection:false) { result in
            guard case .success(let urls)=result, let url=urls.first else { return }
            Task {
                let access=url.startAccessingSecurityScopedResource()
                defer { if access { url.stopAccessingSecurityScopedResource() } }
                if let data=try? Data(contentsOf:url), let text=String(data:data,encoding:.utf8) {
                    packageResult=(try? await store.installRequirements(text,script:selectedScript)) ?? "requirements 安装失败"
                }
            }
        }
    }
    var logPage: some View { ScrollView { Text(store.logs.isEmpty ? "暂无日志" : store.logs).font(.system(.footnote,design:.monospaced)).frame(maxWidth:.infinity,alignment:.leading).textSelection(.enabled).padding() }.navigationTitle("运行日志").toolbar { Button { Task { await store.refresh() } } label:{Image(systemName:"arrow.clockwise")} } }
}

struct AddTaskView: View {
    @ObservedObject var store: Store
    @Environment(\.dismiss) var dismiss
    @State var name="每日任务"; @State var script=""; @State var mode="daily"; @State var time=Calendar.current.date(from:DateComponents(hour:9,minute:0)) ?? .now; @State var minutes=60; @State var days:Set<String>=["mon"]; @State var date=Date()
    let weekDays=[WeekDay(code:"mon",title:"周一"),WeekDay(code:"tue",title:"周二"),WeekDay(code:"wed",title:"周三"),WeekDay(code:"thu",title:"周四"),WeekDay(code:"fri",title:"周五"),WeekDay(code:"sat",title:"周六"),WeekDay(code:"sun",title:"周日")]
    var body: some View { NavigationStack { Form {
        TextField("任务名称",text:$name)
        Picker("执行脚本",selection:$script) { ForEach(store.scripts) { Text($0.name).tag($0.id) } }
        Picker("执行方式",selection:$mode) { Text("每天定时").tag("daily"); Text("间隔执行").tag("interval"); Text("每周定时").tag("weekly"); Text("单次执行").tag("once") }
        if mode == "daily" || mode == "weekly" || mode == "once" { DatePicker("执行时间",selection:$time,displayedComponents:.hourAndMinute) }
        if mode == "weekly" { ForEach(weekDays) { day in Toggle(day.title,isOn:Binding(get:{days.contains(day.code)},set:{v in if v { days.insert(day.code) } else { days.remove(day.code) }})) } }
        if mode == "once" { DatePicker("执行日期",selection:$date,displayedComponents:.date) }
        if mode == "interval" { Stepper("每 \(minutes) 分钟",value:$minutes,in:1...10080) }
    }.navigationTitle("新建任务").toolbar { ToolbarItem(placement:.cancellationAction) { Button("取消"){dismiss()} }; ToolbarItem(placement:.confirmationAction) { Button("保存") { Task { let f=DateFormatter(); f.dateFormat="HH:mm"; let df=DateFormatter(); df.dateFormat="yyyy-MM-dd"; try? await store.addTask(name:name,script:script,mode:mode,time:f.string(from:time),minutes:minutes,days:Array(days),date:df.string(from:date)); dismiss() } }.disabled(script.isEmpty) } } } }
}

import UniformTypeIdentifiers
extension UTType { static var pythonScript: UTType { UTType(filenameExtension:"py") ?? .plainText } }
